RCCG + Tabernacle of Praise — DRAFT REFERENCE PACKAGE

This PNG is an existing reference copy from an RCCG parish website repository. It is not a regenerated emblem and is not claimed to be the original image uploaded in chat.

Source: https://github.com/RCCG-WayForwardProject/rccg-wayforward/blob/b053a99345e9178e23db06ac35b9529006684480/public/logo.svg
PNG SHA256: 977ee1c5a43c30d2859e31f59705da23a53e8c3e7736d1d1376e021c62703340
Native size: (236, 236)

No publication, official production authorization or final lockup approval is implied. Keep the entire emblem unaltered and separate from the parish identity.
