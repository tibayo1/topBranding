# Tabernacle of Praise — editable draft study

DRAFT — NOT FOR PUBLICATION. No logo, palette, or typography is approved.

Open [the offline explorer](brand/explorations/color-study-02/exports/tabernacle-color-explorer.html)
in a browser. It includes all scripts and fonts and needs no installation.

[Study notes](brand/explorations/color-study-02/README.md) contain exact HEX values,
application links, editing instructions, and validation limits.
[Logo meanings and the new D concept](brand/concepts/exploration-03/README.md)
include the visual breakdown, construction source, and tradeoffs.

Folders preserve repository-relative paths so the source builders and links work.
Only the B/C symbol sources needed for the breakdown are included from exploration 01.
